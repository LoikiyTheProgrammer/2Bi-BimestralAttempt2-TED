import { Paciente } from "./interfaces"
export const pacientes: Paciente[] = [
    {
        nome: 'Alan Turing',
        setor: 'ortopedista'
    },
    {
        nome: 'Ada Lovelace',
        setor: 'ortopedista'
    },
    {
        nome: 'Grace Hopper',
        setor: 'cardiologista'
    },
    {
        nome: 'Linus Torvalds',
        setor: 'clínico geral'
    },
    {
        nome: 'Margaret Hamilton',
        setor: 'clínico geral'
    },
    {
        nome: 'Tim Berners-Lee',
        setor: 'cardiologista'
    },
]